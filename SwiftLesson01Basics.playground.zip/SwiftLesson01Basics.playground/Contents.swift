

/*let redColour = "red"
let greenColour = "green"
let blueColour = "blue"

var colour : String

colour = redColour
print(colour)

// uncomment to see a nice print
print("Red colour value = \(redColour)\nGreen color value = \(greenColour)")
*/

/*
>>>>>>>>>>>>>>>
HOMEWORK
>>>>>>>>>>>>>>>
*/

let firstName = "Орест"
let lastName = "Патлика"
let weight = 72
let age = 19
let height = 183

print("Имя студента: \(firstName);")
print("Фамилия студента: \(lastName);")
print("Возраст студента: \(age) лет;")
print("Рост студента: \(height) см;")
print("Вес студента: \(weight) кг;")
